package es.codegym.telegrambot;

import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static es.codegym.telegrambot.TelegramBotContent.*;

public class MyFirstTelegramBot extends MultiSessionTelegramBot {

    public static final String NAME = "MaiHStoreBot";
    public static final String TOKEN = "7679342549:AAHm4LS4J0-dJ2335Cgnhdh_BQ2olBaiUng";
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public MyFirstTelegramBot() {
        super(NAME, TOKEN);
    }

    @Override
    public void onUpdateEventReceived(Update update) {
        try {
            // Comando /start o menú principal
            if (getMessageText().equals("/start") || getCallbackQueryButtonKey().equals("main_menu")) {
                showMainMenu();
            }
            // Módulo de Productos
            else if (getCallbackQueryButtonKey().equals("products_module")) {
                showProductsMenu();
            }
            // Módulo de Cotizaciones
            else if (getCallbackQueryButtonKey().equals("quotes_module")) {
                showQuotesMenu();
            }
            // Módulo de Inventario
            else if (getCallbackQueryButtonKey().equals("inventory_module")) {
                showInventoryMenu();
            }
            // Módulo de Clientes
            else if (getCallbackQueryButtonKey().equals("clients_module")) {
                showClientsMenu();
            }
            // Información del sistema
            else if (getCallbackQueryButtonKey().equals("system_info")) {
                sendSystemInfo();
            }

        } catch (Exception e) {
            sendTextMessageAsync("⚠ Error en el sistema: " + e.getMessage());
        }
    }

    private void showMainMenu() {
        sendPhotoMessageAsync("company_logo");
        sendTextMessageAsync(WELCOME_MSG,
                Map.of(
                        "📦 Productos", "products_module",
                        "📝 Cotizaciones", "quotes_module",
                        "📊 Inventario", "inventory_module",
                        "👥 Clientes", "clients_module",
                        "ℹ Sistema", "system_info"
                ));
    }

    private void showProductsMenu() {
        sendTextMessageAsync(PRODUCTS_MENU,
                Map.of(
                        "🔍 Buscar producto", "product_search",
                        "🗂 Por categoría", "product_by_category",
                        "🏷 Descuentos", "product_discounts",
                        "🆕 Nuevos", "new_products",
                        BACK_MAIN_MENU, "main_menu"
                ));
    }

    private void showQuotesMenu() {
        sendTextMessageAsync(QUOTES_MENU,
                Map.of(
                        "🆕 Nueva", "new_quote",
                        "⏳ Pendientes", "pending_quotes",
                        "🕰 Histórico", "quote_history",
                        "🛒 Convertir", "convert_to_order",
                        BACK_MAIN_MENU, "main_menu"
                ));
    }

    private void showInventoryMenu() {
        sendTextMessageAsync(INVENTORY_MENU,
                Map.of(
                        "🔎 Consultar", "inventory_check",
                        "⚠ Alertas", "inventory_alerts",
                        "📋 Movimientos", "inventory_movements",
                        "✏ Ajustes", "inventory_adjustments",
                        BACK_MAIN_MENU, "main_menu"
                ));
    }

    private void showClientsMenu() {
        sendTextMessageAsync(CLIENTS_MENU,
                Map.of(
                        "➕ Registrar", "client_register",
                        "🔍 Buscar", "client_search",
                        "📋 Historial", "client_history",
                        "💳 Crédito", "client_credit",
                        BACK_MAIN_MENU, "main_menu"
                ));
    }

    private void sendSystemInfo() {
        String user = getCurrentChatId() != null ? "Usuario-" + getCurrentChatId() : "Invitado";
        String info = String.format(SYSTEM_INFO, user, sdf.format(new Date()));

        sendTextMessageAsync(info,
                Map.of(
                        "🔄 Actualizar", "system_info",
                        "📋 Manual", "system_manual",
                        CONTACT_SUPPORT, "contact_support",
                        BACK_MAIN_MENU, "main_menu"
                ));
    }


    public static void main(String[] args) throws TelegramApiException {
        TelegramBotsApi telegramBotsApi = new TelegramBotsApi(DefaultBotSession.class);
        telegramBotsApi.registerBot(new MyFirstTelegramBot());
    }
}