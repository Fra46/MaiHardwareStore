package es.codegym.telegrambot;

public class TelegramBotContent {
    // Mensaje de bienvenida
    public static final String WELCOME_MSG = """
            *⚡ FERRETERÍA INDUSTRIAL MAIHARDWARE ⚡*
            
            Sistema Integral de Gestión Comercial
            
            *Versión 2.1* - ©2025
            
            Seleccione un módulo:""";

    // Módulo de Productos
    public static final String PRODUCTS_MENU = """
            *📦 MÓDULO DE PRODUCTOS*
            
            1. Buscar producto por referencia
            2. Listar por categoría
            3. Productos con descuento
            4. Nuevos ingresos
            
            _Stock total: 1,245 items_""";

    // Módulo de Cotizaciones
    public static final String QUOTES_MENU = """
            *📝 MÓDULO DE COTIZACIONES*
            
            1. Nueva cotización
            2. Cotizaciones pendientes
            3. Histórico de cotizaciones
            4. Convertir a pedido""";

    // Módulo de Inventario
    public static final String INVENTORY_MENU = """
            *📊 MÓDULO DE INVENTARIO*
            
            1. Consultar niveles de stock
            2. Alertas de inventario
            3. Movimientos recientes
            4. Ajustes de inventario""";

    // Módulo de Clientes
    public static final String CLIENTS_MENU = """
            *👥 MÓDULO DE CLIENTES*
            
            1. Registrar nuevo cliente
            2. Buscar cliente
            3. Historial de compras
            4. Crédito disponible""";

    // Mensajes comunes
    public static final String BACK_MAIN_MENU = "Volver al menú principal";
    public static final String CONTACT_SUPPORT = "📞 Contactar con soporte técnico";
    public static final String SYSTEM_INFO = """
            *ℹ INFORMACIÓN DEL SISTEMA*
            
            Usuario: %s
            Sucursal: Principal
            Versión: 2.1.0
            Último acceso: %s""";
}